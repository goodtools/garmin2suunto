var t = 1545887018000
// 2018-12-27T13:03:38
let date = new Date(t + 8 * 3600 * 1000);
// date.
console.log(date.toISOString().substring(0,19))